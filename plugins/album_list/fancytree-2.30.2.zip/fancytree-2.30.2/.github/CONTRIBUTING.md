Thanks for contributing :-)

Please have a look at the 
[Contributing Guidelines](https://github.com/mar10/fancytree/wiki/HowtoContribute#report-issues).
